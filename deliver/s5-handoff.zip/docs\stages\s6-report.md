# S6 编曲结构 / 钢琴卷帘 / MIDI

- 日期：见 git 提交
- 负责人：Agent-E
- 分支建议：`feat/s6-arrangement-midi`

## 1. 交付物

| 文件 | 内容 |
|---|---|
| `lib/models/musical_time.dart` | **新增**。`Ticks`（PPQ = 960）、`MusicalDivision`（含附点/三连音，`1/16`、`1/8T` …）、`MusicalTime`（`snap` / `swingOffset` / `quantize`）。 |
| `lib/models/pattern.dart` | **新增**。`Pattern{id, name, notes, lengthTicks, color}`，JSON 读写用 `start_ticks` / `length_ticks`。 |
| `lib/models/playlist.dart` | **新增**。`PlaylistItem`（含 `transpose`、`trackIndex`）、`Playlist`（items + loop + markers）、`TimeMarker`、`TempoChange`、`ProjectTemplate`（4 个内置模板）。 |
| `lib/models/note.dart` | **改写**。`startTicks` / `lengthTicks` 成为权威字段，`startTime` / `duration` 降为**派生秒视图**（构造时、按 tempo 换算）。新增 `Note.fromSeconds`、`withTempo`、`endTicks`。 |
| `lib/services/playlist_engine.dart` | **新增**。纯函数编曲代数：linked/unique 克隆、增删移动、重叠检测与自动让位、循环区、标记、`expandItem`（块比样式长时自动重复）、`flatten`、以及**旧工程迁移** `fromTracks`。 |

以上均为纯 Dart、无 Flutter 依赖（`playlist_engine.dart` 只依赖 `models/`），
因此可以直接被后续的 Rust 侧 sequencer 复用。

## 2. 关键设计决定

### 2.1 tick 与秒的共存（不破坏旧工程）

`Note` 同时持有 tick 与秒，但**只有 tick 是权威的**：

- 只给秒（旧调用点、旧工程文件）→ 按 tempo 反算 tick；
- 只给 tick → 按 tempo 正算秒；
- `copyWith(startTime:)` 仍然可用，内部转 tick，因此
  `piano_roll_editor.dart` 等现有调用点**无需改动即可编译并保持行为**。

这样 S6 不必等待 S0 完成就能落地，也避免了「一次性全仓改 tick」带来的回归风险。
S0 落地后只需删除秒字段。

### 2.2 旧工程迁移等价性

`PlaylistEngine.fromTracks` 把「每轨一堆 notes」映射为「一轨 = 一个 Pattern + 一块编排」，
块的起点为 tick 0、长度向上取整到整小节，**时间轴逐 tick 等价**，丢失的信息为零。
反向（`flatten`）可精确还原为原 notes 列表。

## 3. ⛔ 阻塞：本会话无法验证

**本会话环境无法运行任何 Flutter / Dart 分析或测试工具链**，因此上文代码
**未经 `flutter analyze` / `flutter test` 验证**，也**未提交**。

已核实的具体症状：

```
> dart analyze lib
Analyzing lib...
CreateFile failed 5 (拒绝访问。)
ProcessException: Access denied (at ../../runtime/bin/process_win.cc:742)
  Command: dartaotruntime.exe ...\analysis_server_aot.dart.snapshot
```

- `dart --version` → 正常（`Dart SDK 3.12.2`）。
- `dartaotruntime.exe analysis_server_aot.dart.snapshot --help` → 正常。
- `dart analyze` → 失败：`dartdev` 用**管道**起 analysis server，沙箱拒绝该管道句柄。
- 已尝试的规避（均无效）：`cmd /c` 重定向到文件、`cmd /c` 把 stderr 送 `NUL`、
  `--format=machine`、`Start-Process -RedirectStandard*`、直接跑 analysis server 快照。
- `flutter.bat` / `dart.bat` 一次输出都没有就挂起（走 `pwsh` 分支），30+ 分钟无结果。
- `dart analyze` 失败时会**吞掉** analysis server 的 argv0，转而打印
  `--client-id=dart-analyze`，所以拿不到诊断输出。

**结论**：这是沙箱（工作区写模式）对命名管道 / 管道式 stdio 的限制，
不是代码问题，也不是命令写错。按计划 §4.2 第 5 条，**未验证的代码不得合入**，
所以本阶段在此停住等待人工决策。

## 4. 恢复后要做的（按顺序）

1. 在**能跑 `flutter analyze` / `flutter test` 的环境**（或对该沙箱放开管道式 stdio）执行：
   ```
   flutter analyze          # 必须零 error
   flutter test             # 必须全绿
   ```
2. 验证 `note.dart` 改动没有波及现有 50 项测试；重点跑
   `lgdf_project_test.dart`、`zaproj_test.dart`（工程格式）。
3. 继续 S6 剩余部分：
   - `lgdf_project_codec.dart`：`patterns` / `playlist` / `markers` / `tempo_changes`
     **可选字段**读写；`parseProjectDocument` 在缺失时调 `fromTracks` 迁移。
   - `project_provider.dart`（881 行，触碰前先按 §0.2 拆到 < 800 行）：
     样式/编排 provider + 撤销接入。
   - `model/` 之外的 UI：编排视图（Playlist 块拖拽摆放）、卷帘量化/摇摆/力度/工具/幽灵音符。
   - `services/midi/smf_reader.dart` + `smf_writer.dart`（SMF 0/1），
     以及 `menu_bar.dart:150` 的 `'MIDI import not yet implemented'` 占位替换。
   - MIDI 输入：`flutter_midi_command` 需要联网 `pub get`，本会话同样做不到；
     若环境离线，需改为 FFI 直连系统 MIDI（Windows 走 `winmm`）。
4. 补测试：tick 换算、SMF 往返、旧工程迁移、量化/摇摆、编排展开。
5. 更新 `docs/PLAN_DAW_PARITY.md` 进度表。

## 5. 风险

| 风险 | 说明 |
|---|---|
| Note 双表示漂移 | 秒视图在 tempo 变化后可能过期。缓解：`withTempo`，以及播放路径上的 `flatten` 一律走 tick。 |
| 未验证代码 | 见 §3。合并前必须跑通 analyze + test。 |
| `pubspec.yaml` 新增 MIDI 依赖 | `flutter_midi_command` 需联网解析，且各平台需原生权限配置；属于 S6c 的独立风险点。 |
