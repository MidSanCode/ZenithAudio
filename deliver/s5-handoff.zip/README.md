# 项目接手包（全部未来步骤 · 2026-10-04 状态快照）

解压到项目根目录（含 pubspec.yaml 与 Cargo.toml 的那层）后即可开工，覆盖同名文件。
本包覆盖从当前状态直到项目收尾的**全部剩余工作**。

## 先读这两个

1. **docs/ROADMAP-FUTURE.md** —— ★ 全部剩余步骤的单一索引：
   5 个批次顺序、每阶段任务/依赖/验收/产出物、跨阶段纪律。
2. **docs/PLAN_DAW_PARITY.md** —— 主计划：§0.2 硬约束、§0.3 技术选型、
   §3 各阶段详细规格、§4 协作规范、§6 进度表。

## 当前状态（已实测核实）

| 阶段 | 状态 |
|---|---|
| S0 基础重构 | ✅ tag s0-baseline |
| S1.0 前置项 A/B/C | ✅ panic 修复 + 适配层 + 34 调用点迁移（122/122） |
| S1.1 引擎主体 | ⬜ ← 批次 1，关键路径 |
| S1.5 Web 接入 | ⬜ 第一段可先行 |
| S2 参数/自动化 | ✅ 316 tests（ABI 0.2.0） |
| S3 混音器 | 🟡 Rust 完成（149 tests，ABI 0.3.0），Dart 门禁未取得 |
| S4 渲染/导出/PDC | ⬜ 等 S1.1 |
| S5 效果器套件 | 🟡 852/8（8 个 distortion 红测 + clippy 8 项 + SIMD 未决）|
| S6 编曲/卷帘/MIDI | 🟡 模型层落地 |
| S7 插件宿主 | ⬜ 等 S1.1 |
| S8 音频编辑 | ⬜ 算法层可先行 |
| S9 收尾 | ⬜ 最后 |

ABI 线性序列：S2=0.2.0 → S3=0.3.0 → S5=0.4.0 → 下一个新增导出 = 0.5.0

## S5 收尾的专门任务书

**docs/stages/s5-handoff.md** —— 8 个红测逐条诊断、环境两大坑
（勿用 PowerShell 写源码 / effects 保持纯 ASCII / process 静默拒绝超尺寸块）。

## 包内容

docs/ROADMAP-FUTURE.md      全部未来步骤路线图（★从这里开始）
docs/PLAN_DAW_PARITY.md     主计划（含 §6 进度表、§4 协作规范）
docs/ABI.md                 C ABI 契约（P1-P10 原则 + 版本规则）
docs/COORDINATION.md        接口变更登记（C-001..C-012，含目录所有权）
docs/stages/s0-report.md    各阶段报告（上游交接证据）
docs/stages/s1-report.md
docs/stages/s2-report.md
docs/stages/s3-report.md
docs/stages/s5-handoff.md   S5 收尾任务书（实测校订版）
docs/stages/s6-report.md

## 契约与纪律（摘要）

- 门禁：cargo clippy --all-targets -- -D warnings / cargo test /
  flutter analyze 0 error / flutter test / cargo check --target wasm32-unknown-unknown
- 不出现任何第三方 DAW 品牌名；禁止 VST（许可与 AGPL-3.0 冲突）
- 共享文件（lib.rs / Cargo.toml / ffi/ / musical_time.dart）改动先登记 COORDINATION
- 只用 write/edit 工具改源码，绝不用 PowerShell 写文件
- 每小步保持仓库可编译可测试；红测默认先怀疑实现